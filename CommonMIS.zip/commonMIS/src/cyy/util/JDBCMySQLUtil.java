package cyy.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

public class JDBCMySQLUtil {
	private static Properties properties = new Properties();
	private static String driver;
	private static String url;
	private static String username;
	private static String password;
	//静态语句块当类载入内存时自动执行
	static {
		try {			
			properties.load(JDBCMySQLUtil.class.getResourceAsStream("/env.properties"));
			driver = properties.getProperty("driver");
			url = properties.getProperty("url");
			username = properties.getProperty("username");
			password = properties.getProperty("password");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	// 获得链接
	private static ThreadLocal<Connection> td = new ThreadLocal<Connection>();
	public static Connection getConnection() {
		Connection conn = td.get();
		try {
			if (conn == null) {
				Class.forName(driver);
				conn = DriverManager.getConnection(url, username, password);
				td.set(conn);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	/**
     * 关闭Connection、tatement、reparedStatement、esultSet 对象
     * @param conn
     * @param stmt
     * @param psmt
     * @param rs
     */
	public static void close(Connection conn,Statement stmt,PreparedStatement psmt,ResultSet rs) {
		if (conn != null) {
			try {
				conn.close();
				td.remove();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (stmt != null) {
			try {
				stmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (psmt != null) {
			try {
				psmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (rs != null) {
			try {
				rs.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		getConnection();
	}
}
