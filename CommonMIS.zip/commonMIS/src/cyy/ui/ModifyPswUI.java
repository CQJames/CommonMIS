package cyy.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.border.TitledBorder;

import cyy.util.JDBCMySQLUtil;

import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class ModifyPswUI extends JDialog {
	private String userName;
	private JPasswordField passwordField;
	private JPasswordField passwordField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ModifyPswUI dialog = new ModifyPswUI("admin");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ModifyPswUI(String userName) {
		this.userName = userName;
		init();
	}

	public void init() {
		this.setTitle("修改密码窗口");
		this.setSize(450, 300);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());
		{
			JLabel label = new JLabel("请谨记你要修改的密码！");
			label.setHorizontalAlignment(SwingConstants.CENTER);
			label.setFont(new Font("宋体", Font.BOLD, 18));
			getContentPane().add(label, BorderLayout.NORTH);
		}
		{
			JPanel panel = new JPanel();
			getContentPane().add(panel, BorderLayout.SOUTH);
			{
				JButton button = new JButton("确定");
				button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						if(String.valueOf(passwordField.getPassword()).equals(""))
						{
							JOptionPane.showMessageDialog(ModifyPswUI.this, "修改密码不能为空！");
						}
						else if(String.valueOf(passwordField_1.getPassword()).equals(""))
						{
							JOptionPane.showMessageDialog(ModifyPswUI.this, "再次密码不能为空！");
						}
						else
						{
							if(String.valueOf(passwordField.getPassword()).equals(
									String.valueOf(passwordField_1.getPassword())))
							{
								try {
									Connection conn = JDBCMySQLUtil.getConnection();
									Statement stmt=conn.createStatement();						   
									String sql="UPDATE regist "
											+ "SET Password="+String.valueOf(passwordField.getPassword())+" "
											+"WHERE UserName="+userName;
									stmt.executeUpdate(sql);
									JDBCMySQLUtil.close(conn, stmt, null, null);
								} catch (SQLException e) {	
									e.printStackTrace();
								}		
							}
							else
							{
								JOptionPane.showMessageDialog(ModifyPswUI.this, "再次密码与初始密码不一致，请重新输入！");
							}
						}
						ModifyPswUI.this.dispose();
					}
				});
				button.setFont(new Font("宋体", Font.BOLD, 18));
				panel.add(button);
			}
			{
				JButton button = new JButton("取消");
				button.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						ModifyPswUI.this.dispose();
					}
				});
				button.setFont(new Font("宋体", Font.BOLD, 18));
				panel.add(button);
			}
		}
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u7528\u6237\u767B\u5F55\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)), "\u8BF7\u586B\u5199\u4FEE\u6539\u5BC6\u7801\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		getContentPane().add(panel, BorderLayout.CENTER);
		
		JLabel label = new JLabel("修改密码：");
		label.setFont(new Font("宋体", Font.BOLD, 18));
		label.setBounds(30, 39, 95, 43);
		panel.add(label);
		
		JLabel label_1 = new JLabel("再次密码：");
		label_1.setFont(new Font("宋体", Font.BOLD, 18));
		label_1.setBounds(30, 92, 95, 43);
		panel.add(label_1);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(20);
		passwordField.setBounds(135, 52, 262, 21);
		panel.add(passwordField);
		
		passwordField_1 = new JPasswordField();
		passwordField_1.setColumns(20);
		passwordField_1.setBounds(135, 105, 262, 21);
		panel.add(passwordField_1);
	}
}
