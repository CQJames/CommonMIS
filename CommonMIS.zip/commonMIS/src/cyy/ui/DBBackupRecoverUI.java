package cyy.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DBBackupRecoverUI extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			DBBackupRecoverUI dialog = new DBBackupRecoverUI();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DBBackupRecoverUI() {
		this.setTitle("数据库备份及恢复窗口");
		this.setSize(450, 300);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("请选择您想要的操作");
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 18));
		lblNewLabel.setBounds(137, 43, 187, 36);
		contentPanel.add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(126, 135, 198, 36);
		contentPanel.add(panel);
		panel.setLayout(new GridLayout(1, 0, 10, 10));
		
		JButton btnNewButton = new JButton("备份");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBBackupRecover.backup();
				JOptionPane.showMessageDialog(DBBackupRecoverUI.this,
						"数据库备份成功！"
						+ "\n"
						+ "文件在：D:\\JavaFiles\\commonMIS\\src\\cyy.sql");
				DBBackupRecoverUI.this.dispose();
				
			}
		});
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("恢复");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBBackupRecover.recover();
				JOptionPane.showMessageDialog(DBBackupRecoverUI.this,
						"数据库恢复成功！");
				DBBackupRecoverUI.this.dispose();
			}
		});
		panel.add(btnNewButton_1);
	}
}
