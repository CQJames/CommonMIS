package cyy.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JDesktopPane;
import javax.swing.JDialog;
import javax.swing.JToolBar;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import cyy.util.JDBCMySQLUtil;

import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Toolkit;


public class MainUI extends JFrame implements ActionListener{
	private String userName;
	private JRadioButtonMenuItem window;
	private JRadioButtonMenuItem metal;
	private JRadioButtonMenuItem motif;
	private JRadioButtonMenuItem nimbus;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainUI frame = new MainUI("admin");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainUI(String userName) {
		this.userName=userName;
		init();
	}

	/**
	 * 
	 */
	public void init() {
		//设置图形界面外观
        try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        Image icon = Toolkit.getDefaultToolkit().getImage("src/cyy/ui/resource/主窗口.jpg"); // 图片的具体位置
        //设置窗口的logo
        this.setIconImage(icon);   
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		JDesktopPane desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.WHITE);
		getContentPane().add(desktopPane, BorderLayout.CENTER);
		
		JToolBar toolBar = new JToolBar();
		getContentPane().add(toolBar, BorderLayout.NORTH);
		
		JButton button = new JButton("\u7528\u6237\u7BA1\u7406");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserManagerUI userManagerUI=new UserManagerUI();
				userManagerUI.setLocation(0, 0);
				desktopPane.add(userManagerUI);
			}
		});
		button.setBackground(Color.WHITE);
		button.setIcon(new ImageIcon("src/cyy/ui/resource/用户管理.gif"));
		toolBar.add(button);
		
		JButton button_1 = new JButton("\u4FE1\u606F\u67E5\u8BE2");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserQueryUI userQueryUI=new UserQueryUI();
				userQueryUI.setLocation(60, 0);
				desktopPane.add(userQueryUI);
			}
		});
		button_1.setBackground(Color.WHITE);
		button_1.setIcon(new ImageIcon("src/cyy/ui/resource/信息查询.gif"));
		toolBar.add(button_1);
		
		JButton button_2 = new JButton("\u6298\u7EBF\u56FE");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MaleFemaleEducationBackgroundLineChart maleFemaleEducationBackgroundLineChart=new MaleFemaleEducationBackgroundLineChart();
				maleFemaleEducationBackgroundLineChart.setLocationRelativeTo(null);
				maleFemaleEducationBackgroundLineChart.setVisible(true);
			}
		});
		button_2.setIcon(new ImageIcon("src/cyy/ui/resource/折线图.gif"));
		button_2.setBackground(Color.WHITE);
		toolBar.add(button_2);
		
		JButton button_3 = new JButton("\u9000\u51FA");
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int d=JOptionPane.showConfirmDialog(MainUI.this, "确认退出本系统？","退出",JOptionPane.YES_NO_CANCEL_OPTION);
				if(d==0)
				{
					System.exit(0);
				}
			}
		});
		button_3.setBackground(Color.WHITE);
		button_3.setIcon(new ImageIcon("src/cyy/ui/resource/退出.gif"));
		toolBar.add(button_3);
		
		JToolBar toolBar_1 = new JToolBar();
		toolBar_1.setToolTipText("");
		getContentPane().add(toolBar_1, BorderLayout.SOUTH);
		
		JLabel label = new JLabel("|当前用户：");
		toolBar_1.add(label);
		
		JLabel lblAdmin = new JLabel(userName);
		toolBar_1.add(lblAdmin);
		
		JLabel label_2 = new JLabel("             |当前系统日期：");
		toolBar_1.add(label_2);
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		JLabel lblTime = new JLabel(df.format(new Date()));
		toolBar_1.add(lblTime);
		
		JLabel lblcopyright = new JLabel("            |@copyright 2018-2030");
		toolBar_1.add(lblcopyright);
		
		JLabel label_1 = new JLabel("             | 地址：肇庆学院紫薇苑111");
		toolBar_1.add(label_1);
	
		setTitle("\u901A\u7528MIS\u7BA1\u7406\u754C\u9762");
		this.setSize(1000, 600);
		this.setLocationRelativeTo(null);
		this.setVisible(true);	
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mne = new JMenu("\u7CFB\u7EDF\u7BA1\u7406(E)");
		menuBar.add(mne);
		
		JMenuItem menuItem_1 = new JMenuItem("数据库备份及恢复");
		menuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DBBackupRecoverUI dBBackupRecoverUI = new DBBackupRecoverUI();
				dBBackupRecoverUI.setVisible(true);
			}
		});
		menuItem_1.setBackground(Color.WHITE);
		menuItem_1.setForeground(Color.BLACK);
		menuItem_1.setIcon(new ImageIcon("src/cyy/ui/resource/数据库备份.gif"));
		mne.add(menuItem_1);
		
		JMenuItem menuItem_2 = new JMenuItem("\u7CFB\u7EDF\u53C2\u6570\u8BBE\u7F6E");
		menuItem_2.setForeground(Color.BLACK);
		menuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(MainUI.this, "对不起，此功能暂未实现！");
			}
		});
		menuItem_2.setBackground(Color.WHITE);
		menuItem_2.setIcon(new ImageIcon("src/cyy/ui/resource/系统参数设置.png"));
		mne.add(menuItem_2);
		// 当前用户信息
		JMenuItem menuItem_3 = new JMenuItem("当前登录者信息");
		menuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CurrentUserMessageUI currentUserMessageUI = new CurrentUserMessageUI(
						userName);
				currentUserMessageUI.setModal(true);
				currentUserMessageUI.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
				currentUserMessageUI.setVisible(true);
			}
		});
		menuItem_3.setBackground(Color.WHITE);
		mne.add(menuItem_3);
		// 修改密码
		JMenuItem menuItem_4 = new JMenuItem("修改登录密码");
		menuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ModifyPswUI modifyPswUI=new ModifyPswUI(userName);
				modifyPswUI.setModal(true);
				modifyPswUI.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
				modifyPswUI.setVisible(true);
			}
		});
		menuItem_4.setBackground(Color.WHITE);
		mne.add(menuItem_4);
		
		JMenuItem menuItem_5 = new JMenuItem("\u9000\u51FA");
		menuItem_5.setForeground(Color.BLACK);
		menuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int d=JOptionPane.showConfirmDialog(MainUI.this, "确认退出本系统？","退出",JOptionPane.YES_NO_CANCEL_OPTION);
				if(d==0)
				{
					System.exit(0);
				}
			}
		});
		menuItem_5.setBackground(Color.WHITE);
		menuItem_5.setIcon(new ImageIcon("src/cyy/ui/resource/退出.gif"));
		mne.add(menuItem_5);
		
		JMenu mnd = new JMenu("\u57FA\u7840\u6570\u636E\u7BA1\u7406(D)");
		menuBar.add(mnd);
		
		JMenuItem menuItem_6 = new JMenuItem("\u89D2\u8272\u7BA1\u7406");
		menuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(MainUI.this, "对不起，此功能暂未实现！"); 
			}
		});
		menuItem_6.setBackground(Color.WHITE);
		mnd.add(menuItem_6);
		
		JMenuItem menuItem_7 = new JMenuItem("\u7528\u6237\u7BA1\u7406");
		menuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserManagerUI userManagerUI=new UserManagerUI();
				userManagerUI.setLocation(0, 0);
				desktopPane.add(userManagerUI);
			}
		});
		menuItem_7.setBackground(Color.WHITE);
		menuItem_7.setIcon(new ImageIcon("src/cyy/ui/resource/用户管理.gif"));
		mnd.add(menuItem_7);
		
		JMenuItem menuItem_8 = new JMenuItem("\u6743\u9650\u7BA1\u7406");
		menuItem_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(MainUI.this, "对不起，此功能暂未实现！");
			}
		});
		menuItem_8.setBackground(Color.WHITE);
		mnd.add(menuItem_8);
		
		JMenuItem menuItem_9 = new JMenuItem("\u6388\u6743\u7BA1\u7406");
		menuItem_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(MainUI.this, "对不起，此功能暂未实现！");
			}
		});
		menuItem_9.setBackground(Color.WHITE);
		mnd.add(menuItem_9);
		
		JMenu mnq = new JMenu("\u67E5\u8BE2\u7EDF\u8BA1(Q)");
		mnq.setBackground(SystemColor.menu);
		menuBar.add(mnq);
		
		JMenuItem menuItem_10 = new JMenuItem("\u4FE1\u606F\u67E5\u8BE2");
		menuItem_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserQueryUI userQueryUI=new UserQueryUI();
				userQueryUI.setLocation(60, 0);
				desktopPane.add(userQueryUI);
			}
		});
		menuItem_10.setBackground(Color.WHITE);
		menuItem_10.setIcon(new ImageIcon("src/cyy/ui/resource/信息查询.gif"));
		mnq.add(menuItem_10);
		
		JMenuItem menuItem_11 = new JMenuItem("\u997C\u56FE");
		menuItem_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MaleFemaleRatioPieChart maleFemaleRatioPieChart=new MaleFemaleRatioPieChart();
				maleFemaleRatioPieChart.setLocationRelativeTo(null);
				maleFemaleRatioPieChart.setVisible(true);
			}
		});
		menuItem_11.setBackground(Color.WHITE);
		menuItem_11.setIcon(new ImageIcon("src/cyy/ui/resource/饼图.jpg"));
		mnq.add(menuItem_11);
		
		JMenuItem menuItem_12 = new JMenuItem("\u6298\u7EBF\u56FE");
		menuItem_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MaleFemaleEducationBackgroundLineChart maleFemaleEducationBackgroundLineChart=new MaleFemaleEducationBackgroundLineChart();
				maleFemaleEducationBackgroundLineChart.setLocationRelativeTo(null);
				maleFemaleEducationBackgroundLineChart.setVisible(true);
			}
		});
		menuItem_12.setBackground(Color.WHITE);
		menuItem_12.setIcon(new ImageIcon("src/cyy/ui/resource/折线图.gif"));
		mnq.add(menuItem_12);
		
		JMenu mnv = new JMenu("\u67E5\u770B(V)");
		mnv.setBackground(SystemColor.menu);
		menuBar.add(mnv);
		
		JCheckBoxMenuItem checkBoxMenuItem = new JCheckBoxMenuItem("\u5DE5\u5177\u680F");
		checkBoxMenuItem.setSelected(true);
		checkBoxMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(checkBoxMenuItem.isSelected())
				{
					toolBar.setVisible(true);
				}
				if(!checkBoxMenuItem.isSelected())
				{
					toolBar.setVisible(false);
				}
			}
		});
		checkBoxMenuItem.setBackground(Color.WHITE);
		mnv.add(checkBoxMenuItem);
		
		JCheckBoxMenuItem checkBoxMenuItem_1 = new JCheckBoxMenuItem("\u72B6\u6001\u680F");
		checkBoxMenuItem_1.setSelected(true);
		checkBoxMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(checkBoxMenuItem_1.isSelected())
				{
					toolBar_1.setVisible(true);
				}
				if(!checkBoxMenuItem_1.isSelected())
				{
					toolBar_1.setVisible(false);
				}
			}
		});
		checkBoxMenuItem_1.setBackground(Color.WHITE);
		mnv.add(checkBoxMenuItem_1);
		
		JMenu mni = new JMenu("\u4E3B\u9898(I)");
		menuBar.add(mni);
		
		window = new JRadioButtonMenuItem("Windows\u98CE\u683C");
		window.setBackground(Color.WHITE);
		mni.add(window);
		
		metal = new JRadioButtonMenuItem("Meta\u98CE\u683C(swing\u9ED8\u8BA4)");
		metal.setBackground(Color.WHITE);
		mni.add(metal);
		
		motif = new JRadioButtonMenuItem("Motif\u98CE\u683C(\u4EFFUnix)");
		motif.setBackground(Color.WHITE);
		mni.add(motif);
		
		nimbus = new JRadioButtonMenuItem("Nimbu\u98CE\u683C");
		nimbus.setSelected(true);
		nimbus.setBackground(Color.WHITE);
		mni.add(nimbus);
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(window);
		bg.add(metal);
		bg.add(motif);
		bg.add(nimbus);
		window.addActionListener(this);
		metal.addActionListener(this);
		motif.addActionListener(this);
		nimbus.addActionListener(this);
		
		JMenu mnh = new JMenu("\u5E2E\u52A9(H)");
		menuBar.add(mnh);
		
		JMenuItem menuItem = new JMenuItem("帮助文档");
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MISHelp mISHelp = new MISHelp();
				mISHelp.setModal(false);
				mISHelp.setLocationRelativeTo(null);
				mISHelp.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				mISHelp.setVisible(true);
			}
		});
		mnh.add(menuItem);
	}

	public void actionPerformed(ActionEvent e) {
		//用于检查是否选择风格
		boolean k=false;
		   String lnfName = null;
		     if (metal.isSelected()) {
		         lnfName = "javax.swing.plaf.metal.MetalLookAndFeel";
		         k=true;
		     } else if (motif.isSelected()) {
		          lnfName = "com.sun.java.swing.plaf.motif.MotifLookAndFeel";
		          k=true;
		     } else if (window.isSelected()) {
		         lnfName = "com.sun.java.swing.plaf.windows.WindowsLookAndFeel";
		         k=true;
		      }
         else if (nimbus.isSelected()) {
                 lnfName =  "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel";
                 k=true;
        }
		    if(k==true) {
		     try {
		    	 //设置图形界面外观
		          UIManager.setLookAndFeel(lnfName);
		          //用来更新look and feel
		        SwingUtilities.updateComponentTreeUI(this);
		      } catch (UnsupportedLookAndFeelException ex1) {
		        System.err.println("Unsupported LookAndFeel: " + lnfName);
		    } catch (ClassNotFoundException ex2) {
		        System.err.println("LookAndFeel class not found: " + lnfName);
		    } catch (InstantiationException ex3) {
		         System.err.println("Could not load LookAndFeel: " + lnfName);
		     } catch (IllegalAccessException ex4) {
		        System.err.println("Cannot use LookAndFeel: " + lnfName);
		    }
		    }
	}
}

