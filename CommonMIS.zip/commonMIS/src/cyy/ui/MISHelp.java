package cyy.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

public class MISHelp extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MISHelp dialog = new MISHelp();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public MISHelp() {
		setTitle("帮助窗口");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		{
			JPanel panel = new JPanel();
			getContentPane().add(panel, BorderLayout.CENTER);
			panel.setLayout(new BorderLayout(0, 0));
			
			JScrollPane scrollPane = new JScrollPane();
			panel.add(scrollPane);
			
			JTextArea textArea = new JTextArea();
			textArea.setText("                                             通用管理信息系统用法\r\n\r\n     一，数据库备份及恢复：数据库既可以备份，又可以恢复，请选择选择你想要的操作。\r\n\r\n     二，当前登录者信息：显示登录本系统的用户信息。\r\n\r\n     三，修改登录密码：修改登录本系统的用户密码。\r\n\r\n     四，退出：退出本系统，会向用户确认一遍是否退出。\r\n\r\n     五，用户管理：管理着所有用户的信息，包括用户编号，用户名，性别，身高，学位，出生日期。其中出生日期可以不选择，即不填。用户名必须填写。\r\n\r\n     六，信息查询：实现了模糊查询，名字寻找“存在输入的字”的名字，性别可以选择男，女，身高可以选择“比较运算符”寻找一个身高范围，学历可以选择博士研究生，硕士研究生，本科，专科，高中，初中，小学，出生日期可以选择一个日期范围。\r\n\r\n     七，饼图统计了所有用户的男女比例，折线图统计了用户男，女学历由低到高的人数变化并作出比较，请选择相应的菜单项查看。\r\n\r\n     八，主题可以选着你喜欢的画面风格。\r\n\r\n     未实现功能：系统参数设置，角色管理，权限管理，授权管理！\r\n     如有不足，多多包涵。欢迎提出意见到我的邮箱，谢谢。     \r\n\r\n     版本：通用信息管理系统1.0\r\n     作者：蔡耀毅\r\n     邮箱：1625186043@qq.com");
			textArea.setLineWrap(true);
			textArea.setCaretPosition(0);
			scrollPane.setViewportView(textArea);
		}
	}
}
