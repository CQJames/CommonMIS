package cyy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.TitledBorder;

import cyy.util.JDBCMySQLUtil;

import javax.swing.JButton;
import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;

import javax.swing.JPasswordField;

public class RegistUI extends JFrame {

	private JPanel contentPane;
	private JTextField jtf_username;
	private JSpinner js_weight;
	private JButton jb_ok;
	private JButton jb_clear;
	private JPasswordField jtf_password1;
	private JPasswordField jtf_password2;
	private JTextField jtf_birth;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RegistUI frame = new RegistUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RegistUI() {
		init();
	}

	/**
	 * 
	 */
	public void init() {
		setTitle("\u6B22\u8FCE\u4F60\u7684\u52A0\u5165");
		// 默认释放窗体
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u8BF7\u586B\u5199\u7528\u6237\u6CE8\u518C\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(5, 1, 0, 0));
		
		JPanel panel_3 = new JPanel();
		panel.add(panel_3);
		
		JLabel label_1 = new JLabel(" 用户名：");
		panel_3.add(label_1);
		
		jtf_username = new JTextField();
		panel_3.add(jtf_username);
		jtf_username.setColumns(20);
		
		JPanel panel_4 = new JPanel();
		panel.add(panel_4);
		
		JLabel label_2 = new JLabel("初始密码：");
		panel_4.add(label_2);
		
		jtf_password1 = new JPasswordField();
		jtf_password1.setColumns(20);
		panel_4.add(jtf_password1);
		
		JPanel panel_5 = new JPanel();
		panel.add(panel_5);
		
		JLabel label_3 = new JLabel("再次密码：");
		panel_5.add(label_3);
		
		jtf_password2 = new JPasswordField();
		jtf_password2.setColumns(20);
		panel_5.add(jtf_password2);
		
		JPanel panel_6 = new JPanel();
		panel.add(panel_6);
		
		JLabel label_4 = new JLabel("出生日期：");
		panel_6.add(label_4);
		
		JButton button = new JButton("选择");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				JDateChooser jDateChooser = new JDateChooser();
				jDateChooser.showDateChooser();
				jtf_birth.setText(jDateChooser.getDateFormat("yyyy-MM-dd"));
			}
		});
		
		jtf_birth = new JTextField();
		jtf_birth.setEditable(false);
		panel_6.add(jtf_birth);
		jtf_birth.setColumns(10);
		panel_6.add(button);
		
		JPanel panel_7 = new JPanel();
		panel.add(panel_7);
		
		JLabel label_5 = new JLabel("体重：");
		panel_7.add(label_5);
		
		js_weight = new JSpinner();
		js_weight.setModel(new SpinnerNumberModel(50.0, 0.0, 300.0, 1.0));
		panel_7.add(js_weight);
		
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.NORTH);
		
		JLabel label = new JLabel("欢迎您的加入");
		panel_1.add(label);
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.SOUTH);
		// 确定按钮
		jb_ok = new JButton("\u786E\u8BA4");
		jb_ok.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if(jtf_username.getText().equals(""))
				{
					JOptionPane.showMessageDialog(RegistUI.this, "用户名不能为空！");
				}
				else if(String.valueOf(jtf_password1.getPassword()).equals(""))
				{
					JOptionPane.showMessageDialog(RegistUI.this, "初始密码不能为空！");
				}
				else if(String.valueOf(jtf_password2.getPassword()).equals(""))
				{
					JOptionPane.showMessageDialog(RegistUI.this, "再次密码不能为空！");
				}
				else
				{
					regist();
				}
			}
			public void regist()
			{
				if(String.valueOf(jtf_password1.getPassword()).equals(
						String.valueOf(jtf_password2.getPassword())))
				{
				    try {
					Connection conn=JDBCMySQLUtil.getConnection();
					Statement stmt=conn.createStatement();
					
					String usercheck="select UserName from regist";
					ResultSet rs=stmt.executeQuery(usercheck);
					boolean isHasUser = false;
					while(rs.next())
					{
						if(rs.getString(1).equals(jtf_username.getText()))
						{
							isHasUser = true;
							break;
						}
					}
					if(!isHasUser)
					{
						String a=jtf_username.getText();
	      				String b=String.valueOf(jtf_password1.getPassword());
		     			String c=jtf_birth.getText();				
	    				// 以空值写入SQL
	    				if(c.equals(""))
	     				{
	    					c = "Null";
	     				}
		    			String d=js_weight.getValue().toString();
		    			String sql="insert into regist values('"+a+"','"+b+"','"+c+"','"+d+"')";			
         				stmt.executeUpdate(sql);
         				JDBCMySQLUtil.close(conn, stmt, null, rs);
         			    // 新建一个登陆界面
    					LoginUI loginUI=new LoginUI();
    					RegistUI.this.dispose();					
					}
					else
					{
						JOptionPane.showMessageDialog(RegistUI.this, "用户已存在！");
					}
					} 
					catch (SQLException e1) 
					{
				    	e1.printStackTrace();
				    }
					
				}
				else
			    {
	    			JOptionPane.showMessageDialog(null,"再次密码与初始密码不一致，请重新输入！");
	    			jtf_password1.setText("");
	    			jtf_password2.setText("");
	    		}
			}
		});
		panel_2.add(jb_ok);
		
		// 清空按钮
		jb_clear = new JButton("\u6E05\u7A7A");
		jb_clear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				jtf_username.setText("");
				jtf_password1.setText("");
				jtf_password2.setText("");
			}
		});
		panel_2.add(jb_clear);
	}

}
