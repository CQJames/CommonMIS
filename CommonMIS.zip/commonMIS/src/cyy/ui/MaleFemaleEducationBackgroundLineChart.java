package cyy.ui;

import java.awt.Font;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import cyy.util.JDBCMySQLUtil;

public class MaleFemaleEducationBackgroundLineChart extends JFrame{
	ChartPanel panel;
	public MaleFemaleEducationBackgroundLineChart(){
		DefaultCategoryDataset linedataset = getDataSet();
		// 定义图表对象
		  JFreeChart chart = ChartFactory.createLineChart("用户男女对比，学历由低到高的人数比较", //折线图名称
		   "学历", // 横坐标名称
		   "人数", // 纵坐标名称
		   linedataset, // 数据
		   PlotOrientation.VERTICAL, // 水平显示图像
		   true, // include legend
		   true, // tooltips
		   false // urls
		   );
	      panel=new ChartPanel (chart,true);
	      CategoryPlot plot=chart.getCategoryPlot();//获取图表区域对象
	      //设置整数显示
	      NumberAxis numberaxis = (NumberAxis) plot.getRangeAxis();
	      numberaxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
	      numberaxis.setAutoRangeIncludesZero(true);
	      // 设置组件显示的字体
	      CategoryAxis domainAxis=plot.getDomainAxis();        
	      domainAxis.setLabelFont(new Font("黑体",Font.BOLD,11));        //水平底部标题
	      domainAxis.setTickLabelFont(new Font("宋体",Font.BOLD,11));  //水平底部列表
	      ValueAxis rangeAxis=plot.getRangeAxis();//获取柱状
	      rangeAxis.setLabelFont(new Font("黑体",Font.BOLD,15));  
	      chart.getTitle().setFont(new Font("宋体",Font.BOLD,20));//设置标题字体
	      chart.getLegend().setItemFont(new Font("黑体",Font.BOLD,15));
	    
	      // 加入到框架
	      this.add(panel);
	      this.setTitle("用户男女对比，学历由低到高的人数比较折线图");
	      this.pack();
	}
    private static DefaultCategoryDataset getDataSet() {
    	int male1=0;
   	   int male2=0;
   	   int male3=0;
   	   int male4=0;
   	   int male5=0;
   	   int male6=0;
   	   int male7=0;
   	   int female1=0;
   	   int female2=0;
   	   int female3=0;
   	   int female4=0;
   	   int female5=0;
   	   int female6=0;
   	   int female7=0;
       try {
   			Connection conn=JDBCMySQLUtil.getConnection();
   			Statement stmt=conn.createStatement();
   			
   			String sql="select * from usermessage";
   		
   			ResultSet rs=stmt.executeQuery(sql);
   			while(rs.next())
   			{
   				if(rs.getString(3).equals("男"))
   				{
   					if(rs.getString(5).equals("小学"))
   					{
   						male1++;
   					}
   					else if(rs.getString(5).equals("初中"))
   					{
   						male2++;
   					}
   					else if(rs.getString(5).equals("高中"))
   					{
   						male3++;
   					}
   					else if(rs.getString(5).equals("专科"))
   					{
   						male4++;
   					}
   					else if(rs.getString(5).equals("本科"))
   					{
   						male5++;
   					}
   					else if(rs.getString(5).equals("硕士研究生"))
   					{
   						male6++;
   					}
   					else if(rs.getString(5).equals("博士研究生"))
   					{
   						male7++;
   					}
   				}
   				else if(rs.getString(3).equals("女"))
   				{
   					if(rs.getString(5).equals("小学"))
   					{
   						female1++;
   					}
   					else if(rs.getString(5).equals("初中"))
   					{
   						female2++;
   					}
   					else if(rs.getString(5).equals("高中"))
   					{
   						female3++;
   					}
   					else if(rs.getString(5).equals("专科"))
   					{
   						female4++;
   					}
   					else if(rs.getString(5).equals("本科"))
   					{
   						female5++;
   					}
   					else if(rs.getString(5).equals("硕士研究生"))
   					{
   						female6++;
   					}
   					else if(rs.getString(5).equals("博士研究生"))
   					{
   						female7++;
   					}
   				}
   			}
   			
   			JDBCMySQLUtil.close(conn, stmt, null, rs);
   		} catch (SQLException e) {
   			
   			e.printStackTrace();
   		}

    	DefaultCategoryDataset linedataset = new DefaultCategoryDataset();
    	 // 各曲线名称
    	  String series1 = "男";
    	  String series2 = "女";
    	  // 横轴名称(列名称)
    	  String type1 = "小学";
    	  String type2 = "初中";
    	  String type3 = "高中";
    	  String type4 = "专科";
    	  String type5 = "本科";
    	  String type6 = "硕士研究生";
    	  String type7 = "博士研究生";
    	  
    	  linedataset.addValue(male1, series1, type1);
    	  linedataset.addValue(male2, series1, type2);
    	  linedataset.addValue(male3, series1, type3);
    	  linedataset.addValue(male4, series1, type4);
    	  linedataset.addValue(male5, series1, type5);
    	  linedataset.addValue(male6, series1, type6);
    	  linedataset.addValue(male7, series1, type7);
    	  
    	  linedataset.addValue(female1, series2, type1);
    	  linedataset.addValue(female2, series2, type2);
    	  linedataset.addValue(female3, series2, type3);
    	  linedataset.addValue(female4, series2, type4);
    	  linedataset.addValue(female5, series2, type5);
    	  linedataset.addValue(female6, series2, type6);
    	  linedataset.addValue(female7, series2, type7);
    	  
    	  return linedataset;
      
    }
}
