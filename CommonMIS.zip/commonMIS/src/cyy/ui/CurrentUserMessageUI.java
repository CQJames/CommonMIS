package cyy.ui;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.TitledBorder;

import cyy.util.JDBCMySQLUtil;

import java.awt.GridLayout;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SpinnerNumberModel;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class CurrentUserMessageUI extends JDialog {
	private JTextField textField;
	private JTextField textField_1;
	private final JPanel panel_3 = new JPanel();
	private String userName;
	private String password;
	private String birthDate;
	private String weight;
	private JTextField textField_2;
	private JSpinner spinner;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			CurrentUserMessageUI dialog = new CurrentUserMessageUI("admin");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public CurrentUserMessageUI(String userName) {
		this.userName = userName;
		try {
			Connection conn = JDBCMySQLUtil.getConnection();
			Statement stmt=conn.createStatement();
			String sql="select * from regist where UserName="+this.userName;
			ResultSet rs=stmt.executeQuery(sql);
			rs.next();
		    this.password = rs.getString(2);
		    this.birthDate = rs.getString(3);
		    this.weight = rs.getString(4);
			JDBCMySQLUtil.close(conn, stmt, null, rs);
		 }
	     catch (SQLException e) {	
			e.printStackTrace();
		} 
		init();
	}

	public void init() {
		this.setTitle("当前用户信息窗口");
		this.setSize(450, 300);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());
		{
			JPanel panel = new JPanel();
			panel.setBorder(new EmptyBorder(5, 5, 5, 5));
			getContentPane().add(panel, BorderLayout.CENTER);
			panel.setLayout(new BorderLayout(0, 0));
			{
				JPanel panel_1 = new JPanel();
				panel.add(panel_1, BorderLayout.NORTH);
				{
					JLabel label = new JLabel("您的信息如下");
					panel_1.add(label);
				}
			}
			{
				JPanel panel_1 = new JPanel();
				panel_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\uFF08\u67E5\u770B\uFF09\u6216\u8005\uFF08\u53EA\u80FD\u4FEE\u6539\u4F53\u91CD\uFF09", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
				panel.add(panel_1, BorderLayout.CENTER);
				panel_1.setLayout(new GridLayout(0, 1, 0, 0));
				{
					JPanel panel_2 = new JPanel();
					panel_1.add(panel_2);
					{
						JLabel label = new JLabel("名字：");
						panel_2.add(label);
					}
					{
						textField = new JTextField();
						textField.setText(userName);
						textField.setEditable(false);
						textField.setColumns(20);
						panel_2.add(textField);
					}
				}
				{
					JPanel panel_2 = new JPanel();
					panel_1.add(panel_2);
					{
						JLabel label = new JLabel("密码：");
						panel_2.add(label);
					}
					{
						textField_2 = new JTextField();
						textField_2.setText(password);
						textField_2.setEditable(false);
						textField_2.setColumns(20);
						panel_2.add(textField_2);
					}
				}
				{
					JPanel panel_2 = new JPanel();
					panel_1.add(panel_2);
					{
						JLabel label = new JLabel("出生日期：");
						panel_2.add(label);
					}
					{
						textField_1 = new JTextField();
						textField_1.setText(birthDate);
						textField_1.setEditable(false);
						textField_1.setColumns(10);
						panel_2.add(textField_1);
					}
				}
				{
					JPanel panel_2 = new JPanel();
					panel_1.add(panel_2);
					panel_2.setLayout(null);
					{
						JLabel label = new JLabel("体重：");
						label.setBounds(165, 8, 47, 15);
						panel_2.add(label);
					}
					{
						spinner = new JSpinner();
						spinner.setBounds(210, 5, 58, 22);
						spinner.setModel(new SpinnerNumberModel(Double.parseDouble(weight), 0, 300, 1));
						panel_2.add(spinner);
					}
				}
				{
					JButton button = new JButton("确定");
					button.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent event) {
							try {
									Connection conn = JDBCMySQLUtil.getConnection();
									Statement stmt=conn.createStatement();						   
									String sql="UPDATE regist "
											+ "SET Weight="+spinner.getValue().toString()+" "
											+"WHERE UserName="+userName;
									stmt.executeUpdate(sql);
									JDBCMySQLUtil.close(conn, stmt, null, null);
									}
							catch (SQLException e) {	
									e.printStackTrace();
								}		
						    CurrentUserMessageUI.this.dispose();
						
						}
					});
					button.setFont(new Font("宋体", Font.BOLD, 18));
					panel_1.add(panel_3);
					panel_3.add(button);
				}
				{
					JButton button = new JButton("取消");
					button.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							CurrentUserMessageUI.this.dispose();
						}
					});
					button.setFont(new Font("宋体", Font.BOLD, 18));
					panel_3.add(button);
				}
			}
			{
				JPanel panel_1 = new JPanel();
				panel.add(panel_1, BorderLayout.SOUTH);
				panel_1.setLayout(new GridLayout(1, 0, 0, 0));
			}
		}
	}

}
