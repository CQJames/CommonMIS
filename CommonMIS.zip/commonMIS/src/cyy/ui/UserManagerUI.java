package cyy.ui;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import cyy.util.JDBCMySQLUtil;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ScrollPaneConstants;
import java.awt.Color;

public class UserManagerUI extends JInternalFrame implements ListSelectionListener,ActionListener{


	private JTextField jtf_user;
	private JTextField jtf_birth;
	private JTable table;
	private JRadioButton rb_male;
	private JRadioButton fb_female;
	private JComboBox cb_edu;
	private JSpinner sp_high;
	
	private JButton jb_add;
	private JButton jb_change;
	private JButton jb_save;
	private JButton jb_delete;
	
	private DefaultTableModel dtm;
	private Object data[][];
	private int model=0;
	private JButton jb_chooseDate;
	private JLabel lblCm;
	
	public void setModel(int model)
	{
		this.model=model;
		if(model==0)
		{
			jb_chooseDate.setEnabled(false);
			jb_add.setEnabled(true);
			jb_change.setEnabled(true);
			jb_save.setEnabled(false);
			jb_delete.setEnabled(true);
			
			set(false);
			
		}
		
		if(model==1 || model==2)
		{
			jb_chooseDate.setEnabled(true);
			jb_add.setEnabled(false);
			jb_change.setEnabled(false);
			jb_save.setEnabled(true);
			jb_delete.setEnabled(false);
			
			set(true);
		}
	}
	
	private void set(boolean b) {
		jtf_user.setEnabled(b);
		jtf_birth.setEnabled(b);
		rb_male.setEnabled(b);
		fb_female.setEnabled(b);
		cb_edu.setEnabled(b);
		sp_high.setEnabled(b);
	}


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserManagerUI frame = new UserManagerUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public UserManagerUI() {
		init();

	}

	public void init() {
		setTitle("\u7528\u6237\u7EFC\u5408\u7BA1\u7406\u7A97\u53E3");
		setClosable(true);
		setIconifiable(true);
		setSize(900, 450);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u7528\u6237\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JPanel panel_1 = new JPanel();
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 853, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, 610, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 228, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(21, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE)
						.addComponent(panel, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 204, Short.MAX_VALUE)
					.addContainerGap())
		);
		Updata_table();
		dtm=new DefaultTableModel(data,new String[] {
				"\u7528\u6237\u7F16\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u8EAB\u9AD8", "\u5B66\u4F4D", "\u51FA\u751F\u65E5\u671F"
			});
		table = new JTable();
		table.setModel(dtm);
		scrollPane.setViewportView(table);
		panel.setLayout(new GridLayout(3, 1, 0, 0));
		
		JPanel panel_6 = new JPanel();
		panel.add(panel_6);
		
		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		
		jtf_user = new JTextField();
		jtf_user.setColumns(10);
		
		JLabel label_1 = new JLabel("\u6027\u522B\uFF1A");
		
		rb_male = new JRadioButton("\u7537");
		rb_male.setSelected(true);
		
		fb_female = new JRadioButton("\u5973");
		
		ButtonGroup bg=new ButtonGroup();
		bg.add(fb_female);
		bg.add(rb_male);
		
		GroupLayout gl_panel_6 = new GroupLayout(panel_6);
		gl_panel_6.setHorizontalGroup(
			gl_panel_6.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_6.createSequentialGroup()
					.addContainerGap()
					.addComponent(label)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(jtf_user, GroupLayout.PREFERRED_SIZE, 181, GroupLayout.PREFERRED_SIZE)
					.addGap(41)
					.addComponent(label_1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(rb_male)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(fb_female)
					.addContainerGap(204, Short.MAX_VALUE))
		);
		gl_panel_6.setVerticalGroup(
			gl_panel_6.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_6.createSequentialGroup()
					.addGap(19)
					.addGroup(gl_panel_6.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(jtf_user, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(rb_male)
						.addComponent(fb_female))
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		panel_6.setLayout(gl_panel_6);
		
		JPanel panel_8 = new JPanel();
		panel.add(panel_8);
		GroupLayout gl_panel_8 = new GroupLayout(panel_8);
		gl_panel_8.setHorizontalGroup(
			gl_panel_8.createParallelGroup(Alignment.LEADING)
				.addGap(0, 598, Short.MAX_VALUE)
		);
		gl_panel_8.setVerticalGroup(
			gl_panel_8.createParallelGroup(Alignment.LEADING)
				.addGap(0, 51, Short.MAX_VALUE)
		);
		panel_8.setLayout(gl_panel_8);
		
		JPanel panel_7 = new JPanel();
		panel.add(panel_7);
		
		JLabel label_2 = new JLabel("\u51FA\u751F\u5E74\u6708\uFF1A");
		
		jtf_birth = new JTextField();
		jtf_birth.setBackground(Color.LIGHT_GRAY);
		jtf_birth.setEditable(false);
		jtf_birth.setColumns(10);
		
		JLabel label_3 = new JLabel("\u5B66\u5386\uFF1A");
		
		cb_edu = new JComboBox();
		cb_edu.setModel(new DefaultComboBoxModel(new String[] {"博士研究生", "硕士研究生", "本科", "专科", "高中", "初中", "小学"}));
		cb_edu.setSelectedIndex(2);
		
		JLabel label_4 = new JLabel("\u8EAB\u9AD8\uFF1A");
		
		sp_high = new JSpinner();
		sp_high.setModel(new SpinnerNumberModel(160.0, 0.0, 300.0, 10.0));
		
		jb_chooseDate = new JButton("选择");
		jb_chooseDate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JDateChooser jDateChooser = new JDateChooser();
				jDateChooser.showDateChooser();
				jtf_birth.setText(jDateChooser.getDateFormat("yyyy-MM-dd"));
			}
		});
		
		lblCm = new JLabel("CM");
		GroupLayout gl_panel_7 = new GroupLayout(panel_7);
		gl_panel_7.setHorizontalGroup(
			gl_panel_7.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_7.createSequentialGroup()
					.addContainerGap()
					.addComponent(label_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(jtf_birth, GroupLayout.PREFERRED_SIZE, 96, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(jb_chooseDate, GroupLayout.PREFERRED_SIZE, 65, GroupLayout.PREFERRED_SIZE)
					.addGap(36)
					.addComponent(label_3)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(cb_edu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(19)
					.addComponent(label_4)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(sp_high, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblCm, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(38, Short.MAX_VALUE))
		);
		gl_panel_7.setVerticalGroup(
			gl_panel_7.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_7.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_panel_7.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(jtf_birth, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_3)
						.addComponent(cb_edu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_4)
						.addComponent(sp_high, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCm))
					.addGap(29))
				.addGroup(gl_panel_7.createSequentialGroup()
					.addContainerGap()
					.addComponent(jb_chooseDate)
					.addContainerGap(28, Short.MAX_VALUE))
		);
		panel_7.setLayout(gl_panel_7);
		panel_1.setLayout(new GridLayout(4, 1, 0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_1.add(panel_2);
		FlowLayout fl_panel_2 = new FlowLayout(FlowLayout.CENTER, 20, 20);
		panel_2.setLayout(fl_panel_2);
		
		jb_add = new JButton("\u589E\u52A0\u7528\u6237");
		panel_2.add(jb_add);
		jb_add.addActionListener(this);
		
		JPanel panel_3 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_3.getLayout();
		flowLayout.setVgap(20);
		panel_1.add(panel_3);
		
		jb_change = new JButton("\u4FEE\u6539\u7528\u6237");
		panel_3.add(jb_change);
		jb_change.addActionListener(this);
		
		JPanel panel_4 = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panel_4.getLayout();
		flowLayout_1.setVgap(20);
		panel_1.add(panel_4);
		
		jb_save = new JButton("\u4FDD\u5B58\u4FE1\u606F");
		panel_4.add(jb_save);
		jb_save.addActionListener(this);
		
		JPanel panel_5 = new JPanel();
		FlowLayout flowLayout_2 = (FlowLayout) panel_5.getLayout();
		flowLayout_2.setVgap(20);
		panel_1.add(panel_5);
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.getSelectionModel().addListSelectionListener(this);
			
		jb_delete = new JButton("\u5220\u9664\u7528\u6237");
		panel_5.add(jb_delete);
		jb_delete.addActionListener(this);
		getContentPane().setLayout(groupLayout);
		setModel(model);
		setVisible(true);
	}
	
	public void valueChanged(ListSelectionEvent arg0) {
		// 选择改变
		textChange();
	}

	//table变化
	private void textChange() 
	{
		int i=table.getSelectedRow();
		if(i>=0)
		{
			jtf_user.setText(table.getValueAt(i, 1).toString());
			
			if((table.getValueAt(i, 2).toString()).equals("男"))
				rb_male.setSelected(true);
			if((table.getValueAt(i, 2).toString()).equals("女"))
				fb_female.setSelected(true);
			
			sp_high.setValue(Double.parseDouble((table.getValueAt(i, 3).toString())));
			cb_edu.setSelectedItem(table.getValueAt(i, 4).toString());
			jtf_birth.setText(table.getValueAt(i, 5).toString());
		}
	}

    private void Updata_table() {
		
		try {
			Connection conn=JDBCMySQLUtil.getConnection();
			Statement stmt=conn.createStatement();
			
			String sql="select * from usermessage";
			
			ResultSet rs=stmt.executeQuery(sql);
			
			rs.last();
			int row = rs.getRow();
			data = new Object[row][6];
			rs.beforeFirst();
			
			while(rs.next())
			{
				for(int i=1;i<=6;i++)
				{
					data[rs.getRow()-1][i-1]=rs.getObject(i);
				}
			}
			
			JDBCMySQLUtil.close(conn, stmt, null, rs);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		
	}
	public void actionPerformed(ActionEvent event) {
		Object obj=event.getSource();
		
		if(obj==jb_add)
		{
            jtf_user.setText("");
			rb_male.setSelected(true);
			sp_high.setValue(160);
			cb_edu.setSelectedItem(3);
			jtf_birth.setText("");
			jtf_user.requestFocus();
			setModel(1);
		}
		
		if(obj==jb_change)
		{
			jtf_user.requestFocus();
			setModel(2);
		}
		
		if(obj==jb_save)
		{
			if(!jtf_user.getText().equals(""))
			{
				if(model==1)	
    			{
					add_SQL();
	    			Updata_table();
	    			dtm=new DefaultTableModel(data,new String[] {
						"\u7528\u6237\u7F16\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u8EAB\u9AD8", "\u5B66\u4F4D", "\u51FA\u751F\u65E5\u671F"
		    			});
		    		table.setModel(dtm);
		    		table.setRowSelectionInterval(table.getRowCount()-1,table.getRowCount()-1);
	    		}
    			if(model==2)
	    		{
	    			int row=table.getSelectedRow();
	    			change_SQL();
		    		Updata_table();
		    		dtm=new DefaultTableModel(data,new String[] {
						"\u7528\u6237\u7F16\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u8EAB\u9AD8", "\u5B66\u4F4D", "\u51FA\u751F\u65E5\u671F"
			    		});
			    	table.setModel(dtm);
		    		table.setRowSelectionInterval(row,row);
		    	}
		    	setModel(0);
			}
			else
			{
				JOptionPane.showMessageDialog(this, "用户名不能为空！");
			}
		}
		
		if(obj==jb_delete)
		{
			int row=table.getSelectedRow();
			int d=JOptionPane.showConfirmDialog(this, "确认删除所选中的用户信息？");
			if(d==0)
				delete_SQL();
			Updata_table();
			dtm=new DefaultTableModel(data,new String[] {
					"\u7528\u6237\u7F16\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u8EAB\u9AD8", "\u5B66\u4F4D", "\u51FA\u751F\u65E5\u671F"
				});
			table.setModel(dtm);
			if(d==0)
			{
				table.setRowSelectionInterval(0,0);
			}
			else
			{
				table.setRowSelectionInterval(row,row);
			}
		}
		
	}
	
	private void add_SQL()  {
		try {
		Connection conn=JDBCMySQLUtil.getConnection();
		Statement stmt= conn.createStatement();;
		
		String a=jtf_user.getText();
		String b;
		if(rb_male.isSelected())
			b="男";
		else
			b="女";
		String c=sp_high.getValue().toString();
		String d=cb_edu.getSelectedItem().toString();
		String e=jtf_birth.getText();
		String f;
		
		String sql1="select * from usermessage";
		ResultSet rs=stmt.executeQuery(sql1);

		int max = 0;
		while(rs.next())
		{
			max = Integer.parseInt(rs.getString(1));
		}
		f=String.valueOf(max+1);
	
		String sql="insert into usermessage values('"+f+"','"+a+"','"+b+"','"+c+"','"+d+"','"+e+"')";	
		stmt.executeUpdate(sql);
		
		JDBCMySQLUtil.close(conn, stmt, null, rs);
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	private void change_SQL(){
		try {
		Connection conn=JDBCMySQLUtil.getConnection();
		Statement stmt=conn.createStatement();
		
		String a=jtf_user.getText();
		String b;
		if(rb_male.isSelected())
			b="男";
		else
			b="女";
		String c=sp_high.getValue().toString();
		String d=cb_edu.getSelectedItem().toString();
		String e=jtf_birth.getText();
		String f=table.getValueAt(table.getSelectedRow(), 0).toString();
		String sql="UPDATE usermessage "
				+ "SET Name='"+a+"',Sex='"+b+"',Height='"+c+"',EducationBackground='"+d+"',BirthDate='"+e+"' "
				+ "WHERE ID='"+f+"'";
		stmt.executeUpdate(sql);
		
		JDBCMySQLUtil.close(conn, stmt, null, null);
		}
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	private void delete_SQL() {
		try {
			Connection conn=JDBCMySQLUtil.getConnection();
			Statement stmt=conn.createStatement();
			
			String a=table.getValueAt(table.getSelectedRow(), 0).toString();
			String sql="DELETE FROM usermessage WHERE ID='"+a+"'";
			stmt.executeUpdate(sql);
				
			JDBCMySQLUtil.close(conn, stmt, null, null);
			
		} catch (SQLException e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
	}

}