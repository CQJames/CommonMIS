package cyy.ui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import cyy.util.JDBCMySQLUtil;

import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JPasswordField;

public class LoginUI extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JButton button;
	private JButton button_1;
	private JButton button_2;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Create the frame.
	 */
	public LoginUI() {
		initUI();
	}

	public void initUI() {
		setTitle("\u767B\u5F55\u7A97\u53E3");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(10, 10));
		setContentPane(contentPane);
		
		JLabel label = new JLabel("\u6B22\u8FCE\u4F7F\u7528\u672C\u7CFB\u7EDF\uFF01");
		label.setFont(new Font("宋体", Font.BOLD, 18));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(label, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "\u7528\u6237\u767B\u5F55\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)), "\u7528\u6237\u767B\u5F55\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u7528\u6237\u540D\uFF1A");
		lblNewLabel.setFont(new Font("宋体", Font.BOLD, 18));
		lblNewLabel.setBounds(30, 39, 84, 43);
		panel.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("\u5BC6  \u7801\uFF1A");
		label_1.setFont(new Font("宋体", Font.BOLD, 18));
		label_1.setBounds(30, 92, 84, 43);
		panel.add(label_1);
		
		textField = new JTextField();
		textField.setColumns(20);
		textField.setBounds(108, 52, 289, 21);
		panel.add(textField);
		
		passwordField = new JPasswordField();
		passwordField.setColumns(20);
		passwordField.setBounds(108, 105, 289, 21);
		panel.add(passwordField);
			
		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.SOUTH);
		
		button = new JButton("\u786E\u5B9A");
		button.setFont(new Font("宋体", Font.BOLD, 18));
		panel_1.add(button);
		button.addActionListener(this);
		
		button_1 = new JButton("\u6CE8\u518C");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_1.setFont(new Font("宋体", Font.BOLD, 18));
		panel_1.add(button_1);
		button_1.addActionListener(this);
		
		button_2 = new JButton("\u53D6\u6D88");
		button_2.setFont(new Font("宋体", Font.BOLD, 18));
		panel_1.add(button_2);
		button_2.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		Object obj=event.getSource();
		// 按了确定按钮
		if(obj == button)
		{
			try {
				Connection conn = JDBCMySQLUtil.getConnection();
				Statement stmt=conn.createStatement();
				String usercheck="select * from regist";
				ResultSet rs=stmt.executeQuery(usercheck);
				boolean isHasUser = false;
				while(rs.next())
				{
					if(rs.getString(1).equals(textField.getText()))
					{
						isHasUser = true;
						if(rs.getString(2).equals(String.valueOf(passwordField.getPassword())))
						{
							this.dispose();
							MainUI indexUI=new MainUI(rs.getString(1));
							break;
						}
						else
						{
							JOptionPane.showMessageDialog(this, "密码错误，请重新输入！");
							break;
						}
					}
				}
				if(!isHasUser)
				{
					JOptionPane.showMessageDialog(this, "用户不存在！");
				}
			 JDBCMySQLUtil.close(conn, stmt, null, rs);
			 }
		     catch (SQLException e) {	
				e.printStackTrace();
			}
		}
		else if(obj==button_1)
		{
			// 按了注册按钮
			this.dispose();
			RegistUI registUI=new RegistUI();
		}
		else if(obj==button_2)
		{
			// 按了取消按钮
			System.exit(0);
		}
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginUI frame = new LoginUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
