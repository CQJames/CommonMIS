package cyy.ui;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cyy.util.JDBCMySQLUtil;

import javax.swing.border.TitledBorder;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.SpinnerNumberModel;
import java.awt.Color;

public class UserQueryUI extends JInternalFrame implements ActionListener{
	private JTable table;
	private JTextField jtf_user;
	private JTextField jtf_birth1;
	private JTextField jtf_birth2;
	private JComboBox cb_sex;
	private JComboBox cb_high;
	private JSpinner sp_high;
	private JComboBox cb_edu;
	private JButton jb_find;

	private Object data[][];
	private DefaultTableModel dtm;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserQueryUI frame = new UserQueryUI();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserQueryUI() {
		init();
	}

	/**
	 * 
	 */
	public void init() {
		setTitle("\u4FE1\u606F\u7EFC\u5408\u67E5\u8BE2\u7A97\u53E3");
		setClosable(true);
		setIconifiable(true);
		setSize(900, 450);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "\u8BF7\u8F93\u5165\u67E5\u8BE2\u6761\u4EF6", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(scrollPane, Alignment.LEADING)
						.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 844, Short.MAX_VALUE))
					.addGap(30))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
					.addContainerGap())
		);
		panel.setLayout(new GridLayout(2, 1, 0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1);
		
		JLabel label = new JLabel("\u7528\u6237\u540D\uFF1A");
		
		jtf_user = new JTextField();
		jtf_user.setColumns(10);
		
		JLabel label_1 = new JLabel("\u6027\u522B\uFF1A");
		
		cb_sex = new JComboBox();
		cb_sex.setModel(new DefaultComboBoxModel(new String[] {"\u7537", "\u5973"}));
		
		JLabel label_2 = new JLabel("\u8EAB\u9AD8\uFF1A");
		
		cb_high = new JComboBox();
		cb_high.setModel(new DefaultComboBoxModel(new String[] {">=", "<=", ">", "<", "=", "!="}));
		
		sp_high = new JSpinner();
		sp_high.setModel(new SpinnerNumberModel(160.0, 0.0, 300.0, 10.0));
		
		JLabel lblCm = new JLabel("CM\r\n");
		
		JLabel label_4 = new JLabel("\u5B66\u5386\uFF1A");
		
		cb_edu = new JComboBox();
		cb_edu.setModel(new DefaultComboBoxModel(new String[] {"博士研究生", "硕士研究生", "本科", "专科", "高中", "初中", "小学"}));
		cb_edu.setSelectedIndex(2);
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addComponent(label)
					.addGap(18)
					.addComponent(jtf_user, GroupLayout.PREFERRED_SIZE, 163, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addComponent(label_1)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(cb_sex, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
					.addGap(37)
					.addComponent(label_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(cb_high, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(sp_high, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblCm)
					.addGap(50)
					.addComponent(label_4)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(cb_edu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(102, Short.MAX_VALUE))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(28)
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(jtf_user, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(cb_sex, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(cb_high, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(sp_high, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(cb_edu, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCm)
						.addComponent(label_1)
						.addComponent(label_4)
						.addComponent(label_2))
					.addContainerGap(29, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		
		JPanel panel_2 = new JPanel();
		panel.add(panel_2);
		
		JLabel label_5 = new JLabel("\u51FA\u751F\u5E74\u6708\u4ECB\u4E8E\uFF1A");
		
		jtf_birth1 = new JTextField();
		jtf_birth1.setBackground(Color.LIGHT_GRAY);
		jtf_birth1.setEditable(false);
		jtf_birth1.setColumns(10);
		
		JLabel label_6 = new JLabel("\u548C");
		
		jtf_birth2 = new JTextField();
		jtf_birth2.setBackground(Color.LIGHT_GRAY);
		jtf_birth2.setEditable(false);
		jtf_birth2.setColumns(10);
		
		JLabel label_7 = new JLabel("\u4E4B\u95F4");
		
		jb_find = new JButton("\u67E5\u8BE2");
		jb_find.setForeground(Color.RED);
		
		JButton button = new JButton("选择");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JDateChooser jDateChooser = new JDateChooser();
				jDateChooser.showDateChooser();
				jtf_birth1.setText(jDateChooser.getDateFormat("yyyy-MM-dd"));
			}
		});
		
		JButton button_1 = new JButton("选择");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JDateChooser jDateChooser = new JDateChooser();
				jDateChooser.showDateChooser();
				jtf_birth2.setText(jDateChooser.getDateFormat("yyyy-MM-dd"));
			}
		});
		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2.setHorizontalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addContainerGap()
					.addComponent(label_5)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(jtf_birth1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(button)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(label_6)
					.addGap(12)
					.addComponent(jtf_birth2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(button_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(label_7)
					.addPreferredGap(ComponentPlacement.RELATED, 292, Short.MAX_VALUE)
					.addComponent(jb_find)
					.addGap(55))
		);
		gl_panel_2.setVerticalGroup(
			gl_panel_2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_2.createSequentialGroup()
					.addGap(24)
					.addGroup(gl_panel_2.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_5)
						.addComponent(jtf_birth1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(jtf_birth2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(button_1)
						.addComponent(label_7)
						.addComponent(jb_find)
						.addComponent(button)
						.addComponent(label_6))
					.addContainerGap(32, Short.MAX_VALUE))
		);
		panel_2.setLayout(gl_panel_2);
		
		Updata_data();
		dtm=new DefaultTableModel(data,
				new String[] {
					"\u7528\u6237\u7F16\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u8EAB\u9AD8", "\u5B66\u4F4D", "\u51FA\u751F\u65E5\u671F"
				}
			);
		table = new JTable();
		table.setModel(dtm);
		scrollPane.setViewportView(table);
		getContentPane().setLayout(groupLayout);

		jb_find.addActionListener(this);
		
		setVisible(true);
	}
	
	private void Updata_data() {
		
		try {
			Connection conn=JDBCMySQLUtil.getConnection();
			Statement stmt=conn.createStatement();
			
			String sql="select * from usermessage";
			
			ResultSet rs=stmt.executeQuery(sql);
			
			rs.last();
			int row = rs.getRow();
			data = new Object[row][6];
			rs.beforeFirst();
			while(rs.next())
			{
				for(int i=1;i<=6;i++)
				{
					data[rs.getRow()-1][i-1]=rs.getObject(i);
				}
			}
			
		    JDBCMySQLUtil.close(conn, stmt, null, rs);
				
			} catch (SQLException e) {
				// TODO 自动生成的 catch 块
				   e.printStackTrace();
		}
	}

	
	public void actionPerformed(ActionEvent arg0) {
		
		try {
			Connection conn=JDBCMySQLUtil.getConnection();
			Statement stmt=conn.createStatement();
			
			String a=jtf_user.getText();
			String b;
			if(cb_sex.getSelectedItem().equals("男"))
				b="男";
			else
				b="女";
			// 身高范围
			String c=cb_high.getSelectedItem().toString();
			String d=sp_high.getValue().toString();
			
			String e=cb_edu.getSelectedItem().toString();
			// 出生日期范围
			String f=jtf_birth1.getText();
			String g=jtf_birth2.getText();
			
			String sql="select * from usermessage where";
			if(!a.equals(""))
			{
				sql=sql + " Name like '%"+a+"%'";
				sql = sql + " and Sex='"+b+"'";
			}
			else
			{
				sql = sql + " Sex='"+b+"'";
			}
			sql = sql + " and Height"+c+d;
			sql = sql + " and EducationBackground='"+e+"'";
			if(!(f.equals("")||g.equals("")))
			{
				sql=sql + " and BirthDate between '"+f+"' and '"+g+"'";
			}
			ResultSet rs=stmt.executeQuery(sql);
			rs.last();
			int row = rs.getRow();
			data = new Object[row][6];
			rs.beforeFirst();
			while(rs.next())
			{
				for(int i=1;i<=6;i++)
				{
					data[rs.getRow()-1][i-1]=rs.getObject(i);
				}
			}
			dtm=new DefaultTableModel(data,
					new String[] {
						"\u7528\u6237\u7F16\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u8EAB\u9AD8", "\u5B66\u4F4D", "\u51FA\u751F\u65E5\u671F"
					}
				);
			table.setModel(dtm);
			if(row!=0)
		    {
				table.addRowSelectionInterval(0, row-1);
		    }

            JDBCMySQLUtil.close(conn, stmt, null, null);
		    } catch (SQLException e) {
			// TODO 自动生成的 catch 块
			   e.printStackTrace();
		    }
	}
}
